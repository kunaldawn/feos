IMPORTANT PC SNOOD INFORMATION (Read Me)
-----------------------------------------------------------------------

PC SNOOD README Version 2.1 
Thank you for trying PC Snood. This document contains information 
about this version of PC Snood and about what I intend to add to future 
versions. If you have any questions or wish to report your experience 
with this version, please send e-mail to: dob@kagi.com

DISCLAIMER: 
You try PC Snood at your own risk. Although I hope that PC Snood will 
work for you, I offer no warranty or claim that PC Snood will 
work correctly or meet your needs.  I do not ask you to pay for 
PC Snood in advance, so if it does not work, do not pay for it.

SPECIFICATIONS:
To run PC Snood, you need to have the following: 

An IBM-compatible computer with a keyboard and mouse 
A video card capable of displaying 640x480 pixels and 256 colors (VESA)
A recent version of Windows 95 or 98, 3.1, or MS-DOS

NOTE:  THIS VERSION USUALLY DOES NOT RUN ON WINDOWS NT!!!
A previous beta version (0.2) did support Windows NT, but the DirectX 
libraries I was using made the game way too slow for many people.  I am 
now using DJGPP and the Allegro game library (version 3.1).  
Unfortunately, this library doesn't support Windows NT.  I'll try to 
get an NT compatible version out, either by improving the DirectX 
version or by getting this version to work under NT.
 
WHAT WORKS:
The game plays reasonably well on most fast PCs.  The Child, Easy, 
Medium, Hard, Evil, Custom, Puzzle, and Journey difficulty levels all 
function exactly as they do on the Mac version. The Custom and Puzzle 
difficulty settings do not work yet without the program being 
registered.  You can start a new game, play it, be awarded bonus 
points if you win, and get an entry on the high score list. Win/loss 
statistics are calculated, and high scores and other information are 
saved to the disk and restored each time you run Snood.  

I have improved the menus, and the options now work.  The Pause 
feature is somewhat limited; you can pause to get to Snood's menus, 
but you can't suspend Snood and go back to Windows.

WHAT DOESN'T WORK NOW BUT WILL SOON: 

I don�t yet have a level editor, but that should come soon.

TIPS:
Snood takes over the whole screen.  Because it runs under DOS, it is 
often impossible to suspend Snood temporarily and go back to Windows.
You have to quit out of Snood entirely to get back to Windows.  If your
computer has one of the funky new Windows metakeys, that key will 
probably get you to Windows, but Snood will probably crash.

You can quit by picking Quit from the Game menu.  If you're in the 
middle of a game, hitting Q should quit the program and A should abort 
your current game. In a pinch, Ctrl-Alt-Del usually allows you to 
terminate the game as well (pick End Task for Snood).

REGISTERING:
If this version of PC Snood works well for you and you find it
enjoyable, please consider registering it for $10.00.  If you play
Snood for more than 30 days, you must register or delete Snood 
from your computer.  

There are several ways to register:

1) You can do register by credit card over a secure (SSL) link on the 
WWW at this address:

https://order.kagi.com?UD

2) You can register by credit card, check, money order, or US or other 
currency through Kagi using the Register program provided with Snood.

3) You can send me a check or money order in U.S. funds, or you can 
send me U.S. currency.  If you send cash, please wrap it in paper
to prevent it from being stolen during transport.  Send these
payments to:

Dave Dobson (PC Snood)
5203 Candlewick Road
Greensboro, NC 27455

NOTE ON KAGI:  Kagi is a payment processing service I use to handle 
credit card and web transactions.  I do not own or run Kagi; I am 
just a client of theirs.  Kagi handles payments for many hundreds 
of products.

For your $10 registration, you will get the following benefits:

  * You won't get the "Please!" screen when the game starts up
 
  * You will see your name listed as the registered user

  * You will be able to use the Custom Difficulty settings
 
  * You will be able to play alternate Puzzle level sets that
    you or others make with SnoodEdit (there are about 20 extra
    sets in the archive now).

  * You will be able to play Tournaments of Snood with up to four 
    players

  * You will be notified of any new versions or upgrades to Snood

  * You will be able to play Snood legally beyond the 30-day 
    trial period, and you will be supporting me and 
    encouraging me to create more software.

E-mail me if you have any questions at dob@kagi.com

-------------------------------------------------------------------
POSSIBLE PROBLEMS:

Some users reported problems or errors with the beta-testing version
of PC Snood.  I have attempted to correct these problems, but the
variety of computer architectures, hardware, software, and operating 
systems in the PC world makes writing a perfect program very 
difficult.  Luckily, Snood is shareware, so you can try it out before
paying to see if Snood works for you.

Here are a list of problems that people experienced with the beta-test 
version of Snood:

1) Snood causes the computer to reboot
	I have not been able to see this drastic problem in action, so
I don't know exactly what is causing it.  I have added more 
error-detection routines, so hopefully I can pin this down.

2) Snood refuses to start and returns to Windows
	This can happen for several reasons, and I have added error-
detection routines to explain why it is happening.  Here are some
potential problems:

* In DOS or Windows 3.1, this can happen if there is no DPMI memory 
management.  Snood will request a program called "CSDPMI*.ZIP".
This program is provided with Snood; just get to a DOS prompt
and run CWSDPMI.EXE before running SNOOD.EXE

* This can also happen if your computer can't support the graphics mode
that Snood needs, which is 640x480 pixels, 256 colors.  This is a VESA
standard SVGA screen which most video cards can accomplish.  In this
version of Snood, I also allow you to try an 800x600 mode with the
Snood Screen in the upper left corner of the screen.  This may let
you play.  If you think your graphics card should allow 640x480 256
colors but Snood is failing to run and/or asking for UniVBE, you migth try
getting UniVBE (a separate shareware product) from 
 http://www.scitechsoft.com

3) Snood crashes frequently during play
	I have removed some problems which could cause Snood to crash,
but since Snood does not crash on my PC, it is hard for me to figure
out what causes crashing.  If there is a specific activity you perform
within Snood which causes Snood to crash, please let me know what it is.  
Any information would be helpful.

4) Snood plays but has no sound
	I changed the sound management a bit, but this may still 
happen for several reasons.  If you are using a Gravis Ultra-Sound
card, no driver exists for the Allegro library to use the GUS, and
it is impossible to run Snood that way unless you can get your GUS
to emulate a SoundBlaster or AdLib card somehow.  Also, if you don't
run Snood in fullscreen mode from Windows, Windows may reserve sound
control and not allow Snood to take control of the sound system.
Make sure Snood is running in fullscreen mode (check Properties on 
the Snood program).  You can also force Snood to try to be SoundBlaster
compatible by going to the Snood directory and running snood by typing
"snood sb" at a DOS command prompt.

5) Snood disables my network services/printing after I am done 
   playing
	I don't know why this is happening, since Snood should not be
affecting any of these things.  It has been reported by about 10 
people, and I have been unable to duplicate it on my machines.  For 
all of these people, rebooting their machines fixes the problem.  It's
not great, but at least it's not a permanent thing.  If you have any
insight on this, let me know.

6) Snood runs painfully slowly
	There is a speed limit feature in Snood which keeps Snood from
running too fast.  Go to "Game Preferences" under the Preferences menu
to turn the speed limit off - you should see a (possibly small) increase
in game speed.  If you're running Snood on a 386, you may be out of luck.

7) Snood runs way, way too fast
	There is a speed limit feature in Snood which keeps Snood from
running too fast.  Go to "Game Preferences" under the Preferences menu
to make sure the speed limit is turned on.

HOW YOU CAN HELP ME:
I would love to hear your experience with and suggestions for PC Snood. 
If you write me, please include the following information: 

* What kind of computer you have, including your processor speed and 
memory 

* What version of Windows you use 

* What your frame rate is. To figure this out, hit "F" while the game 
is in progress. You should see two numbers appear briefly down by the 
score. Snood is generally playable when the top number is less than 
about 10, and the speed limit should keep these numbers from getting 
below 3-4. The second number will be smaller than the first and is also 
helpful to me. I don't need to know all the decimal places - just "3.4" 
or whatever will do.

* Any other problems or difficulties you found. 

* Any suggestions you have for improvements to the game

PLEASE, PLEASE, write me even if it works fine.  For the first few 
beta versions, about 99% of the letters I got were from people for 
whom it didn't work right, but I know from other sources that it 
wasn't nearly that bad.  I'd love to know that Snood works for you.

Send any info or bug reports to:
dob@kagi.com
Thanks!

